package com.example.hotel.entities;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "visitors")
@Data
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode(of="id")
@Builder
public class Visitor {

    @Id
    private long id;

    private String firstName;

    private String lastName;

    private LocalDate birthDay;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    private List<Reservation> reservations;

    int age = birthDay.compareTo(LocalDate.now());

    public void addRes(Reservation res){
        this.reservations.add(res);
    }
}
