package com.example.hotel.services;

import org.springframework.stereotype.Service;

@Service
public class ReservationService {

    private int resId = 1;


}
